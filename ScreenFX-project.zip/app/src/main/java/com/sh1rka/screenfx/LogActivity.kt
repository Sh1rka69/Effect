package com.sh1rka.screenfx

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class LogActivity : AppCompatActivity() {

    private lateinit var logText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log)

        logText = findViewById(R.id.logText)
        refreshLog()

        findViewById<MaterialButton>(R.id.btnCopyLog).setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("ScreenFX log", logText.text.toString())
            clipboard.setPrimaryClip(clip)
            Toast.makeText(this, "Лог скопирован в буфер обмена", Toast.LENGTH_SHORT).show()
        }

        findViewById<MaterialButton>(R.id.btnClearLog).setOnClickListener {
            AppLog.clear()
            refreshLog()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshLog()
    }

    private fun refreshLog() {
        logText.text = AppLog.readAll()
    }
}
