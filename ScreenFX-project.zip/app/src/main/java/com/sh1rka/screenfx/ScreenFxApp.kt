package com.sh1rka.screenfx

import android.app.Application

class ScreenFxApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppLog.installCrashHandler(this)
        AppLog.d("App", "Приложение запущено")
    }
}
