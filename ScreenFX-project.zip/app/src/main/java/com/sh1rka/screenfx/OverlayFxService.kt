package com.sh1rka.screenfx

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.renderscript.Allocation
import android.renderscript.Element
import android.renderscript.RenderScript
import android.renderscript.ScriptIntrinsicBlur
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class OverlayFxService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        private const val CHANNEL_ID = "screenfx_channel"
        private const val NOTIF_ID = 1001
        private const val TAG = "OverlayFxService"
    }

    private var mediaProjection: MediaProjection? = null
    private var mediaProjectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private lateinit var windowManager: WindowManager

    // Full-screen view that paints the processed frame
    private var renderView: FxRenderView? = null
    private var renderParams: WindowManager.LayoutParams? = null

    // Small floating control to stop the effect from within a game
    private var controlView: View? = null
    private var controlParams: WindowManager.LayoutParams? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    private var renderScript: RenderScript? = null

    // Drives the hide -> capture -> show cycle that keeps our own overlays
    // out of the captured frame (see startCaptureLoop() for why this
    // replaces a naive AUTO_MIRROR + continuous listener approach).
    private val captureHandler = Handler(Looper.getMainLooper())
    private var captureLoopRunning = false
    private val captureIntervalMs = 66L // ~15fps: plenty for a screen filter, keeps the hide/show blip short and rare

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        AppLog.init(this)
        AppLog.d(TAG, "onCreate")
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        renderScript = try {
            RenderScript.create(this).also { AppLog.d(TAG, "RenderScript created OK") }
        } catch (t: Throwable) {
            AppLog.e(TAG, "RenderScript.create failed — blur will be disabled", t)
            null
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        AppLog.d(TAG, "onStartCommand called")
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData: Intent? = intent?.getParcelableExtra(EXTRA_RESULT_DATA)

        startForeground(NOTIF_ID, buildNotification())
        AppLog.d(TAG, "startForeground OK")

        if (resultData == null) {
            AppLog.e(TAG, "resultData is null — projection intent missing, stopping")
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            // Use LOGICAL metrics (getMetrics), not physical (getRealMetrics).
            // getRealMetrics reports the panel's native resolution, which can
            // mismatch the size the system is actually compositing windows at
            // when a custom `wm size` override is active — creating a
            // VirtualDisplay/ImageReader at the wrong size can crash immediately.
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getMetrics(metrics)
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
            screenDensity = metrics.densityDpi
            AppLog.d(TAG, "Screen metrics: ${screenWidth}x${screenHeight} density=$screenDensity")

            val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
            AppLog.d(TAG, "MediaProjection acquired: ${mediaProjection != null}")

            // Android 14+ requires a registered callback before createVirtualDisplay,
            // so the app can clean up if the user revokes screen-capture permission
            // (e.g. from the persistent notification) while the effect is running.
            val callback = object : MediaProjection.Callback() {
                override fun onStop() {
                    AppLog.d(TAG, "MediaProjection.Callback.onStop — захват экрана остановлен системой")
                    stopSelf()
                }
            }
            mediaProjectionCallback = callback
            mediaProjection?.registerCallback(callback, Handler(Looper.getMainLooper()))
            AppLog.d(TAG, "MediaProjection callback registered")

            startCapture()
            AppLog.d(TAG, "startCapture OK")
            addRenderOverlay()
            AppLog.d(TAG, "addRenderOverlay OK")
            addControlOverlay()
            AppLog.d(TAG, "addControlOverlay OK")
        } catch (t: Throwable) {
            AppLog.e(TAG, "Ошибка при запуске эффекта", t)
            stopSelf()
            return START_NOT_STICKY
        }

        return START_STICKY
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    private fun startCapture() {
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ScreenFXCapture",
            screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        // We deliberately do NOT use a continuous setOnImageAvailableListener
        // here. AUTO_MIRROR mirrors the entire physical display, and our own
        // renderView/controlView are drawn on that same display — so a
        // continuous listener would capture a frame that already contains
        // our overlay's previous output, compositing on top of itself every
        // tick and producing an infinite receding "hall of mirrors".
        //
        // The correct fix is to make sure our overlay is not on screen at
        // the instant a frame is grabbed. FLAG_SECURE would do that but it
        // also blocks the user's own screenshots/screen recording system-wide,
        // which is not what we want here. Instead we run our own paced loop:
        // set both overlay windows' LayoutParams.alpha to 0 (a lightweight
        // SurfaceFlinger compositing change, not a WindowManager relayout —
        // see setOverlayAlpha()), wait one composited frame, grab it, then
        // restore alpha to 1. Using alpha instead of View.visibility is what
        // keeps this from being a visible flicker.
        captureLoopRunning = true
        scheduleNextCapture()
    }

    private fun scheduleNextCapture() {
        if (!captureLoopRunning) return
        captureHandler.postDelayed({ captureOneFrame() }, captureIntervalMs)
    }

    private fun captureOneFrame() {
        if (!captureLoopRunning) return
        val reader = imageReader
        if (reader == null) {
            scheduleNextCapture()
            return
        }

        // Hide via LayoutParams.alpha, NOT View.visibility.
        // visibility = INVISIBLE/GONE forces a full WindowManagerService
        // relayout of the window (performTraversals with a visibility state
        // change) — on many devices that round-trip is slow enough to be
        // visible as an actual flicker/flash every capture cycle.
        // alpha is a pure SurfaceFlinger compositing property: setting it to
        // 0 and calling updateViewLayout just changes how the already-drawn
        // surface is blended for the next frame, no relayout, no visible
        // pop. This is what keeps the hide/show blip imperceptible.
        val renderWasVisible = (renderParams?.alpha ?: 1f) > 0f
        val controlWasVisible = (controlParams?.alpha ?: 1f) > 0f
        setOverlayAlpha(renderView, renderParams, 0f)
        setOverlayAlpha(controlView, controlParams, 0f)

        // Wait for one real composited frame with alpha=0 before reading
        // from the ImageReader — otherwise we might grab a frame that was
        // already queued while the overlay was still visible.
        android.view.Choreographer.getInstance().postFrameCallback {
            if (!captureLoopRunning) return@postFrameCallback
            try {
                val image = try { reader.acquireLatestImage() } catch (t: Throwable) { null }
                if (image != null) {
                    try {
                        val bitmap = imageToBitmap(image)
                        renderView?.updateFrame(bitmap)
                    } catch (t: Throwable) {
                        AppLog.e(TAG, "Ошибка обработки кадра", t)
                    } finally {
                        image.close()
                    }
                }
            } finally {
                if (renderWasVisible) setOverlayAlpha(renderView, renderParams, 1f)
                if (controlWasVisible) setOverlayAlpha(controlView, controlParams, 1f)
                scheduleNextCapture()
            }
        }
    }

    private fun setOverlayAlpha(view: View?, params: WindowManager.LayoutParams?, alpha: Float) {
        if (view == null || params == null || view.windowToken == null) return
        params.alpha = alpha
        try {
            windowManager.updateViewLayout(view, params)
        } catch (_: IllegalArgumentException) {
            // View was detached mid-cycle (service stopping) — safe to ignore.
        }
    }

    private fun stopCaptureLoop() {
        captureLoopRunning = false
        captureHandler.removeCallbacksAndMessages(null)
    }

    private fun imageToBitmap(image: android.media.Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * screenWidth

        val bitmap = Bitmap.createBitmap(
            screenWidth + rowPadding / pixelStride,
            screenHeight,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        return if (bitmap.width != screenWidth) {
            Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight)
        } else bitmap
    }

    private fun addRenderOverlay() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        renderParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        renderView = FxRenderView(this, renderScript)
        windowManager.addView(renderView, renderParams)
    }

    private fun addControlOverlay() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        controlParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 120
        }

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_control, null)
        controlView = view

        val closeBtn = view.findViewById<View>(R.id.overlayCloseBtn)
        closeBtn.setOnClickListener {
            stopSelf()
        }

        // Make the pill draggable so it never permanently blocks game UI
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        view.setOnTouchListener { touchedView, event ->
            // Guard: a queued touch can arrive after the service has already
            // removed this view (onDestroy / a restart racing an in-flight
            // drag), which crashes updateViewLayout with
            // "View not attached to window manager". Bail out safely instead.
            if (touchedView.windowToken == null || controlView == null) {
                return@setOnTouchListener false
            }
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = controlParams!!.x
                    initialY = controlParams!!.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    controlParams!!.x = initialX + (event.rawX - touchX).toInt()
                    controlParams!!.y = initialY + (event.rawY - touchY).toInt()
                    try {
                        windowManager.updateViewLayout(controlView, controlParams)
                    } catch (_: IllegalArgumentException) {
                        // View was detached between the null-check above and this
                        // call (race with onDestroy) — safe to ignore.
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(controlView, controlParams)
    }

    override fun onDestroy() {
        super.onDestroy()
        AppLog.d(TAG, "onDestroy")
        stopCaptureLoop()
        try { renderView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        try { controlView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        imageReader?.close()
        virtualDisplay?.release()
        try {
            mediaProjectionCallback?.let { mediaProjection?.unregisterCallback(it) }
        } catch (_: Exception) {}
        mediaProjection?.stop()
        renderScript?.destroy()
    }
}

/**
 * Full-screen, non-touchable view that draws the latest captured frame
 * with brightness/saturation/contrast/vignette/fisheye/blur/bloom applied.
 */
class FxRenderView(
    context: Context,
    private val rs: RenderScript?
) : View(context) {

    @Volatile private var latestBitmap: Bitmap? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bloomPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
    }

    // Bloom result, computed off the main draw path in updateFrame() so onDraw stays cheap.
    @Volatile private var latestBloom: Bitmap? = null

    // --- Fisheye mesh state ---
    // Note: this view runs LAYER_TYPE_SOFTWARE (see init{} below) specifically
    // because drawBitmapMesh's vertex displacement is unreliable on the
    // hardware-accelerated canvas.
    private val meshW = 24
    private val meshH = 32
    private val meshVerts = FloatArray((meshW + 1) * (meshH + 1) * 2)
    private var meshBuiltForWidth = -1
    private var meshBuiltForHeight = -1
    private var meshBuiltForStrength = -1f

    init {
        // CRITICAL: must be SOFTWARE, not HARDWARE.
        // Android's hardware-accelerated canvas (hwui/Skia GPU backend) only
        // supports a subset of Canvas/Paint operations. Two of them are used
        // here and BOTH silently misbehave under LAYER_TYPE_HARDWARE instead
        // of throwing, which is why this was invisible until traced:
        //  - drawBitmapMesh: on hardware layers this can render as a plain
        //    rectangular blit, ignoring the mesh vertex displacement entirely
        //    -> the fisheye warp geometry was simply never applied.
        //  - Paint.xfermode with PorterDuff.Mode.SCREEN: several blend modes
        //    are unsupported/approximated on the GPU backend. Instead of a
        //    proper screen-blend (which is a no-op for black), the bloom
        //    layer's black background was composited as ordinary alpha-over-black
        //    -> it visibly darkened the whole frame instead of glowing it.
        // Software rendering executes the real Skia CPU path, where both
        // operations are fully implemented and behave as documented.
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        rebuildColorFilter()
    }

    private fun rebuildColorFilter() {
        val b = FxSettings.brightness
        val s = FxSettings.saturation
        val c = FxSettings.contrast

        val saturationMatrix = ColorMatrix()
        saturationMatrix.setSaturation(s)

        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, (-0.5f * c + 0.5f) * 255f,
                0f, c, 0f, 0f, (-0.5f * c + 0.5f) * 255f,
                0f, 0f, c, 0f, (-0.5f * c + 0.5f) * 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )

        val brightnessMatrix = ColorMatrix(
            floatArrayOf(
                1f, 0f, 0f, 0f, (b - 1f) * 255f,
                0f, 1f, 0f, 0f, (b - 1f) * 255f,
                0f, 0f, 1f, 0f, (b - 1f) * 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )

        val combined = ColorMatrix()
        combined.postConcat(saturationMatrix)
        combined.postConcat(contrastMatrix)
        combined.postConcat(brightnessMatrix)

        paint.colorFilter = ColorMatrixColorFilter(combined)
    }

    fun updateFrame(bitmap: Bitmap) {
        rebuildColorFilter()

        val blurAmount = FxSettings.blur
        val blurred = if (blurAmount > 0.01f && rs != null) {
            applyBlur(bitmap, blurAmount)
        } else {
            bitmap
        }

        val bloomAmount = FxSettings.bloom
        latestBloom = if (bloomAmount > 0.01f && rs != null) {
            try {
                buildBloomLayer(blurred, bloomAmount)
            } catch (t: Throwable) {
                AppLog.e("FxRenderView", "Bloom failed", t)
                null
            }
        } else {
            null
        }

        latestBitmap = blurred
        post { invalidate() }
    }

    private fun applyBlur(src: Bitmap, amount: Float): Bitmap {
        return try {
            // Downscale for performance before blurring — full-res RS blur is too slow for real-time.
            val scale = 0.35f
            val small = Bitmap.createScaledBitmap(
                src, (src.width * scale).toInt().coerceAtLeast(1),
                (src.height * scale).toInt().coerceAtLeast(1), true
            )
            val input = Allocation.createFromBitmap(rs, small)
            val output = Allocation.createTyped(rs, input.type)
            val script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs))
            script.setRadius((amount * 25f).coerceIn(1f, 25f))
            script.setInput(input)
            script.forEach(output)
            output.copyTo(small)
            Bitmap.createScaledBitmap(small, src.width, src.height, true)
        } catch (t: Throwable) {
            AppLog.e("FxRenderView", "Blur failed, showing unblurred frame", t)
            src
        }
    }

    /**
     * Bloom: keep only pixels brighter than a threshold (soft knee, not a hard
     * cutoff), scaling their contribution by how far over the threshold they
     * are — so a near-white pixel contributes far more glow than a
     * just-barely-bright one. That bright-only layer is then heavily blurred
     * so it spreads into a soft halo, and later screen-blended back onto the
     * frame in onDraw(). "amount" controls both the threshold (lower
     * threshold = more of the image blooms) and the blur radius/strength.
     */
    private fun buildBloomLayer(src: Bitmap, amount: Float): Bitmap {
        // Work small: bloom is a low-frequency soft glow, doesn't need full res,
        // and this keeps threshold extraction + blur cheap enough for real-time.
        val scale = 0.25f
        val w = (src.width * scale).toInt().coerceAtLeast(1)
        val h = (src.height * scale).toInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(src, w, h, true)

        val pixels = IntArray(w * h)
        small.getPixels(pixels, 0, w, 0, 0, w, h)

        // More bloom strength -> lower threshold, so more of the image starts glowing.
        val threshold = (0.85f - amount * 0.45f).coerceIn(0.3f, 0.85f)
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = Color.red(p) / 255f
            val g = Color.green(p) / 255f
            val b = Color.blue(p) / 255f
            // Perceptual luminance decides how "bright" a pixel counts as.
            val luma = 0.2126f * r + 0.7152f * g + 0.0722f * b
            if (luma <= threshold) {
                // Fully transparent, not just black: this is drawn back with
                // SCREEN blending where opaque black is already a no-op, but
                // making it truly transparent means even a device/driver that
                // falls back to plain alpha compositing for this xfermode
                // still can't darken the frame — only the glow itself shows.
                pixels[i] = Color.TRANSPARENT
            } else {
                // Overshoot past the threshold, normalized 0..1, then boosted —
                // this is what makes brighter pixels bloom disproportionately harder.
                val over = ((luma - threshold) / (1f - threshold)).coerceIn(0f, 1f)
                val gain = (over * over) * (1f + amount * 1.5f)
                pixels[i] = Color.argb(
                    255,
                    (r * gain * 255f).toInt().coerceIn(0, 255),
                    (g * gain * 255f).toInt().coerceIn(0, 255),
                    (b * gain * 255f).toInt().coerceIn(0, 255)
                )
            }
        }
        small.setPixels(pixels, 0, w, 0, 0, w, h)

        val input = Allocation.createFromBitmap(rs, small)
        val output = Allocation.createTyped(rs, input.type)
        val script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs))
        script.setRadius((8f + amount * 17f).coerceIn(1f, 25f))
        script.setInput(input)
        script.forEach(output)
        output.copyTo(small)

        return small
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = latestBitmap ?: return

        val fisheye = FxSettings.fisheye
        if (fisheye > 0.01f && bmp.width > 0 && bmp.height > 0) {
            buildFisheyeMesh(fisheye, bmp.width, bmp.height)
            canvas.save()
            // drawBitmapMesh verts are in the bitmap's own coordinate space, so
            // scale the canvas from bitmap size to view size first (the two
            // are normally equal — both full screen — but this keeps it
            // correct if they ever diverge).
            canvas.scale(width / bmp.width.toFloat(), height / bmp.height.toFloat())
            canvas.drawBitmapMesh(bmp, meshW, meshH, meshVerts, 0, null, 0, paint)
            canvas.restore()
        } else {
            val srcRect = Rect(0, 0, bmp.width, bmp.height)
            val dstRect = Rect(0, 0, width, height)
            canvas.drawBitmap(bmp, srcRect, dstRect, paint)
        }

        latestBloom?.let { bloom ->
            val srcRect = Rect(0, 0, bloom.width, bloom.height)
            val dstRect = Rect(0, 0, width, height)
            canvas.drawBitmap(bloom, srcRect, dstRect, bloomPaint)
        }

        val vignette = FxSettings.vignette
        if (vignette > 0.01f) {
            drawVignette(canvas, vignette)
        }
    }

    /**
     * Builds a bulging barrel-distortion mesh: each grid vertex is pushed
     * outward from center by an amount that grows with distance from center
     * (a classic r' = r * (1 + k*r^2) style warp, normalized to the view's
     * half-diagonal). This is what actually makes the image look like it's
     * bulging through a fisheye/glass-dome lens, not just darkened at the
     * edges. Rebuilt only when size or strength changes, not every frame.
     */
    private fun buildFisheyeMesh(strength: Float, bmpWidth: Int, bmpHeight: Int) {
        if (meshBuiltForWidth == bmpWidth && meshBuiltForHeight == bmpHeight && meshBuiltForStrength == strength) {
            return
        }
        val w = bmpWidth.toFloat()
        val h = bmpHeight.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val maxR = kotlin.math.hypot(cx, cy)
        // k controls bulge intensity; tuned so strength=1 gives a strong, obviously
        // spherical bulge without folding pixels back on themselves at the corners.
        val k = strength * 0.55f

        var index = 0
        for (yi in 0..meshH) {
            val fy = h * yi / meshH
            for (xi in 0..meshW) {
                val fx = w * xi / meshW
                val dx = fx - cx
                val dy = fy - cy
                val r = kotlin.math.hypot(dx, dy) / maxR // normalized 0..1
                // Bulge outward: pixels near center move little, pixels near
                // the edge get pushed further out, producing the classic
                // convex "looking through a glass sphere" distortion.
                val factor = 1f + k * (r * r)
                val nx = (cx + dx * factor).coerceIn(0f, w)
                val ny = (cy + dy * factor).coerceIn(0f, h)
                meshVerts[index++] = nx
                meshVerts[index++] = ny
            }
        }
        meshBuiltForWidth = bmpWidth
        meshBuiltForHeight = bmpHeight
        meshBuiltForStrength = strength
    }

    private fun drawVignette(canvas: Canvas, strength: Float) {
        val cx = width / 2f
        val cy = height / 2f
        val radius = (width.coerceAtLeast(height)) * (1.1f - strength * 0.5f)

        val vignettePaint = Paint()
        vignettePaint.shader = RadialGradient(
            cx, cy, radius,
            intArrayOf(Color.TRANSPARENT, Color.BLACK),
            floatArrayOf(1f - strength, 1f),
            Shader.TileMode.CLAMP
        )
        vignettePaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_OVER)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), vignettePaint)
    }
}
