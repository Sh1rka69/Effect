package com.sh1rka.screenfx

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.renderscript.Allocation
import android.renderscript.Element
import android.renderscript.RenderScript
import android.renderscript.ScriptIntrinsicBlur
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class OverlayFxService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        private const val CHANNEL_ID = "screenfx_channel"
        private const val NOTIF_ID = 1001
        private const val TAG = "OverlayFxService"
    }

    private var mediaProjection: MediaProjection? = null
    private var mediaProjectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private lateinit var windowManager: WindowManager

    // Full-screen view that paints the processed frame
    private var renderView: FxRenderView? = null
    private var renderParams: WindowManager.LayoutParams? = null

    // Small floating control to stop the effect from within a game
    private var controlView: View? = null
    private var controlParams: WindowManager.LayoutParams? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    private var renderScript: RenderScript? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        AppLog.init(this)
        AppLog.d(TAG, "onCreate")
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        renderScript = try {
            RenderScript.create(this).also { AppLog.d(TAG, "RenderScript created OK") }
        } catch (t: Throwable) {
            AppLog.e(TAG, "RenderScript.create failed — blur will be disabled", t)
            null
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        AppLog.d(TAG, "onStartCommand called")
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData: Intent? = intent?.getParcelableExtra(EXTRA_RESULT_DATA)

        startForeground(NOTIF_ID, buildNotification())
        AppLog.d(TAG, "startForeground OK")

        if (resultData == null) {
            AppLog.e(TAG, "resultData is null — projection intent missing, stopping")
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            // Use LOGICAL metrics (getMetrics), not physical (getRealMetrics).
            // getRealMetrics reports the panel's native resolution, which can
            // mismatch the size the system is actually compositing windows at
            // when a custom `wm size` override is active — creating a
            // VirtualDisplay/ImageReader at the wrong size can crash immediately.
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getMetrics(metrics)
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
            screenDensity = metrics.densityDpi
            AppLog.d(TAG, "Screen metrics: ${screenWidth}x${screenHeight} density=$screenDensity")

            val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
            AppLog.d(TAG, "MediaProjection acquired: ${mediaProjection != null}")

            // Android 14+ requires a registered callback before createVirtualDisplay,
            // so the app can clean up if the user revokes screen-capture permission
            // (e.g. from the persistent notification) while the effect is running.
            mediaProjectionCallback = object : MediaProjection.Callback() {
                override fun onStop() {
                    AppLog.d(TAG, "MediaProjection.Callback.onStop — захват экрана остановлен системой")
                    stopSelf()
                }
            }
            mediaProjection?.registerCallback(mediaProjectionCallback, Handler(Looper.getMainLooper()))
            AppLog.d(TAG, "MediaProjection callback registered")

            startCapture()
            AppLog.d(TAG, "startCapture OK")
            addRenderOverlay()
            AppLog.d(TAG, "addRenderOverlay OK")
            addControlOverlay()
            AppLog.d(TAG, "addControlOverlay OK")
        } catch (t: Throwable) {
            AppLog.e(TAG, "Ошибка при запуске эффекта", t)
            stopSelf()
            return START_NOT_STICKY
        }

        return START_STICKY
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    private fun startCapture() {
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ScreenFXCapture",
            screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val image = try { reader.acquireLatestImage() } catch (e: Exception) { null } ?: return@setOnImageAvailableListener
            try {
                val bitmap = imageToBitmap(image)
                renderView?.updateFrame(bitmap)
            } catch (t: Throwable) {
                AppLog.e(TAG, "Ошибка обработки кадра", t)
            } finally {
                image.close()
            }
        }, null)
    }

    private fun imageToBitmap(image: android.media.Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * screenWidth

        val bitmap = Bitmap.createBitmap(
            screenWidth + rowPadding / pixelStride,
            screenHeight,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        return if (bitmap.width != screenWidth) {
            Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight)
        } else bitmap
    }

    private fun addRenderOverlay() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        renderParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        renderView = FxRenderView(this, renderScript)
        windowManager.addView(renderView, renderParams)
    }

    private fun addControlOverlay() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        controlParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 120
        }

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_control, null)
        controlView = view

        val closeBtn = view.findViewById<View>(R.id.overlayCloseBtn)
        closeBtn.setOnClickListener {
            stopSelf()
        }

        // Make the pill draggable so it never permanently blocks game UI
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = controlParams!!.x
                    initialY = controlParams!!.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    controlParams!!.x = initialX + (event.rawX - touchX).toInt()
                    controlParams!!.y = initialY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(controlView, controlParams)
                    true
                }
                else -> false
            }
        }

        windowManager.addView(controlView, controlParams)
    }

    override fun onDestroy() {
        super.onDestroy()
        AppLog.d(TAG, "onDestroy")
        try { renderView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        try { controlView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        imageReader?.close()
        virtualDisplay?.release()
        try {
            mediaProjectionCallback?.let { mediaProjection?.unregisterCallback(it) }
        } catch (_: Exception) {}
        mediaProjection?.stop()
        renderScript?.destroy()
    }
}

/**
 * Full-screen, non-touchable view that draws the latest captured frame
 * with brightness/saturation/contrast/vignette/blur applied.
 */
class FxRenderView(
    context: Context,
    private val rs: RenderScript?
) : View(context) {

    @Volatile private var latestBitmap: Bitmap? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
        rebuildColorFilter()
    }

    private fun rebuildColorFilter() {
        val b = FxSettings.brightness
        val s = FxSettings.saturation
        val c = FxSettings.contrast

        val saturationMatrix = ColorMatrix()
        saturationMatrix.setSaturation(s)

        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, (-0.5f * c + 0.5f) * 255f,
                0f, c, 0f, 0f, (-0.5f * c + 0.5f) * 255f,
                0f, 0f, c, 0f, (-0.5f * c + 0.5f) * 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )

        val brightnessMatrix = ColorMatrix(
            floatArrayOf(
                1f, 0f, 0f, 0f, (b - 1f) * 255f,
                0f, 1f, 0f, 0f, (b - 1f) * 255f,
                0f, 0f, 1f, 0f, (b - 1f) * 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )

        val combined = ColorMatrix()
        combined.postConcat(saturationMatrix)
        combined.postConcat(contrastMatrix)
        combined.postConcat(brightnessMatrix)

        paint.colorFilter = ColorMatrixColorFilter(combined)
    }

    fun updateFrame(bitmap: Bitmap) {
        rebuildColorFilter()

        val blurAmount = FxSettings.blur
        val processed = if (blurAmount > 0.01f && rs != null) {
            applyBlur(bitmap, blurAmount)
        } else {
            bitmap
        }

        latestBitmap = processed
        post { invalidate() }
    }

    private fun applyBlur(src: Bitmap, amount: Float): Bitmap {
        return try {
            // Downscale for performance before blurring — full-res RS blur is too slow for real-time.
            val scale = 0.35f
            val small = Bitmap.createScaledBitmap(
                src, (src.width * scale).toInt().coerceAtLeast(1),
                (src.height * scale).toInt().coerceAtLeast(1), true
            )
            val input = Allocation.createFromBitmap(rs, small)
            val output = Allocation.createTyped(rs, input.type)
            val script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs))
            script.setRadius((amount * 25f).coerceIn(1f, 25f))
            script.setInput(input)
            script.forEach(output)
            output.copyTo(small)
            Bitmap.createScaledBitmap(small, src.width, src.height, true)
        } catch (e: Exception) {
            src
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = latestBitmap ?: return
        val srcRect = Rect(0, 0, bmp.width, bmp.height)
        val dstRect = Rect(0, 0, width, height)
        canvas.drawBitmap(bmp, srcRect, dstRect, paint)

        val vignette = FxSettings.vignette
        if (vignette > 0.01f) {
            drawVignette(canvas, vignette)
        }
    }

    private fun drawVignette(canvas: Canvas, strength: Float) {
        val cx = width / 2f
        val cy = height / 2f
        val radius = (width.coerceAtLeast(height)) * (1.1f - strength * 0.5f)

        val vignettePaint = Paint()
        vignettePaint.shader = RadialGradient(
            cx, cy, radius,
            intArrayOf(Color.TRANSPARENT, Color.BLACK),
            floatArrayOf(1f - strength, 1f),
            Shader.TileMode.CLAMP
        )
        vignettePaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_OVER)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), vignettePaint)
    }
}
