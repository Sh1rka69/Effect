package com.sh1rka.screenfx

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.renderscript.Allocation
import android.renderscript.Element
import android.renderscript.RenderScript
import android.renderscript.ScriptIntrinsicBlur
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class OverlayFxService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        private const val CHANNEL_ID = "screenfx_channel"
        private const val NOTIF_ID = 1001
        private const val TAG = "OverlayFxService"
    }

    private var mediaProjection: MediaProjection? = null
    private var mediaProjectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private lateinit var windowManager: WindowManager

    // Full-screen view that paints the processed frame
    private var renderView: FxRenderView? = null
    private var renderParams: WindowManager.LayoutParams? = null

    // Small floating control to stop the effect from within a game
    private var controlView: View? = null
    private var controlParams: WindowManager.LayoutParams? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    private var renderScript: RenderScript? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        AppLog.init(this)
        AppLog.d(TAG, "onCreate")
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        renderScript = try {
            RenderScript.create(this).also { AppLog.d(TAG, "RenderScript created OK") }
        } catch (t: Throwable) {
            AppLog.e(TAG, "RenderScript.create failed — blur will be disabled", t)
            null
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        AppLog.d(TAG, "onStartCommand called")
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData: Intent? = intent?.getParcelableExtra(EXTRA_RESULT_DATA)

        startForeground(NOTIF_ID, buildNotification())
        AppLog.d(TAG, "startForeground OK")

        if (resultData == null) {
            AppLog.e(TAG, "resultData is null — projection intent missing, stopping")
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            // If the effect is already running (user pressed "Применить" again
            // with new slider values while it was active), tear down the
            // previous capture/overlay state FIRST. Without this, every press
            // stacked a brand new FxRenderView on top of the old one (which
            // was never removed) and leaked the old MediaProjection/
            // VirtualDisplay/ImageReader — so the visible result could be an
            // old, stale, or wrong-settings view sitting on top of or under
            // the new one depending on z-order, while logs from the NEW
            // instance looked perfectly correct.
            cleanupPreviousSession()

            // Use LOGICAL metrics (getMetrics), not physical (getRealMetrics).
            // getRealMetrics reports the panel's native resolution, which can
            // mismatch the size the system is actually compositing windows at
            // when a custom `wm size` override is active — creating a
            // VirtualDisplay/ImageReader at the wrong size can crash immediately.
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getMetrics(metrics)
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
            screenDensity = metrics.densityDpi
            AppLog.d(TAG, "Screen metrics: ${screenWidth}x${screenHeight} density=$screenDensity")

            val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
            AppLog.d(TAG, "MediaProjection acquired: ${mediaProjection != null}")

            // Android 14+ requires a registered callback before createVirtualDisplay,
            // so the app can clean up if the user revokes screen-capture permission
            // (e.g. from the persistent notification) while the effect is running.
            val callback = object : MediaProjection.Callback() {
                override fun onStop() {
                    AppLog.d(TAG, "MediaProjection.Callback.onStop — захват экрана остановлен системой")
                    stopSelf()
                }
            }
            mediaProjectionCallback = callback
            mediaProjection?.registerCallback(callback, Handler(Looper.getMainLooper()))
            AppLog.d(TAG, "MediaProjection callback registered")

            startCapture()
            AppLog.d(TAG, "startCapture OK")
            addRenderOverlay()
            AppLog.d(TAG, "addRenderOverlay OK")
            addControlOverlay()
            AppLog.d(TAG, "addControlOverlay OK")
        } catch (t: Throwable) {
            AppLog.e(TAG, "Ошибка при запуске эффекта", t)
            stopSelf()
            return START_NOT_STICKY
        }

        return START_STICKY
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
    }

    private fun startCapture() {
        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "ScreenFXCapture",
            screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        // AUTO_MIRROR mirrors the entire physical display, which would
        // normally include our own renderView/controlView overlays and
        // cause them to recursively appear inside their own captured frame
        // (the "hall of mirrors" effect). We previously tried excluding the
        // overlay from just the capture by racing an alpha/visibility toggle
        // against the compositor on a timer — that depends on how fast a
        // given device's WindowManagerService/SurfaceFlinger applies an
        // async transaction relative to our own Choreographer callback, so
        // it was never reliable across devices (sometimes still recursed,
        // sometimes visibly flickered).
        //
        // renderView/controlView are created with FLAG_SECURE (see
        // addRenderOverlay()/addControlOverlay()), which deterministically
        // excludes them from ANY screen capture at the compositor level —
        // no timing dependency at all. The tradeoff, by design: while the
        // effect is active, the user's own screenshots/screen recording are
        // also blocked system-wide (a Android platform-level restriction of
        // FLAG_SECURE, not something we can selectively apply to just this
        // virtual display). Screenshots work normally again once the effect
        // is turned off. This was a deliberate choice to guarantee a clean,
        // full-screen, non-flickering effect over being able to screenshot
        // the effect itself.
        var loggedFirstFrame = false
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = try { reader.acquireLatestImage() } catch (t: Throwable) { null } ?: return@setOnImageAvailableListener
            try {
                val bitmap = imageToBitmap(image)
                if (!loggedFirstFrame) {
                    loggedFirstFrame = true
                    AppLog.d(TAG, "Первый кадр получен: ${bitmap.width}x${bitmap.height}")
                }
                renderView?.updateFrame(bitmap)
            } catch (t: Throwable) {
                AppLog.e(TAG, "Ошибка обработки кадра", t)
            } finally {
                image.close()
            }
        }, null)
    }

    private fun imageToBitmap(image: android.media.Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * screenWidth

        val bitmap = Bitmap.createBitmap(
            screenWidth + rowPadding / pixelStride,
            screenHeight,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        return if (bitmap.width != screenWidth) {
            Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight)
        } else bitmap
    }

    private fun addRenderOverlay() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        renderParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                // Deterministically excludes this window from ANY screen
                // capture (MediaProjection AND the user's own screenshot/
                // screen recording) at the compositor level. This is what
                // stops the recursive "hall of mirrors" reliably, with no
                // timing dependency. Tradeoff accepted: screenshots of the
                // effect itself are blocked while it's active; normal
                // screenshots work again once the effect is off.
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        renderView = FxRenderView(this, renderScript)
        windowManager.addView(renderView, renderParams)
    }

    private fun addControlOverlay() {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        controlParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20
            y = 120
        }

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_control, null)
        controlView = view

        val closeBtn = view.findViewById<View>(R.id.overlayCloseBtn)
        closeBtn.setOnClickListener {
            stopSelf()
        }

        // Make the pill draggable so it never permanently blocks game UI
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        view.setOnTouchListener { touchedView, event ->
            // Guard: a queued touch can arrive after the service has already
            // removed this view (onDestroy / a restart racing an in-flight
            // drag), which crashes updateViewLayout with
            // "View not attached to window manager". Bail out safely instead.
            if (touchedView.windowToken == null || controlView == null) {
                return@setOnTouchListener false
            }
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = controlParams!!.x
                    initialY = controlParams!!.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    controlParams!!.x = initialX + (event.rawX - touchX).toInt()
                    controlParams!!.y = initialY + (event.rawY - touchY).toInt()
                    try {
                        windowManager.updateViewLayout(controlView, controlParams)
                    } catch (_: IllegalArgumentException) {
                        // View was detached between the null-check above and this
                        // call (race with onDestroy) — safe to ignore.
                    }
                    true
                }
                else -> false
            }
        }

        windowManager.addView(controlView, controlParams)
    }

    /**
     * Tears down everything from a previous capture/overlay session: removes
     * both overlay windows, closes the image reader, releases the virtual
     * display, unregisters and stops the old projection. Safe to call when
     * nothing is running yet (all no-ops guarded). Does NOT touch
     * renderScript, which is created once in onCreate and lives for the
     * whole service lifetime.
     */
    private fun cleanupPreviousSession() {
        val hadRenderView = renderView != null
        val hadControlView = controlView != null
        val hadProjection = mediaProjection != null
        if (hadRenderView || hadControlView || hadProjection) {
            AppLog.d(TAG, "cleanupPreviousSession: очищаю предыдущую сессию (renderView=$hadRenderView controlView=$hadControlView projection=$hadProjection)")
        }
        try { renderView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        renderView = null
        try { controlView?.let { windowManager.removeView(it) } } catch (_: Exception) {}
        controlView = null
        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try {
            mediaProjectionCallback?.let { mediaProjection?.unregisterCallback(it) }
        } catch (_: Exception) {}
        try { mediaProjection?.stop() } catch (_: Exception) {}
        mediaProjection = null
        mediaProjectionCallback = null
    }

    override fun onDestroy() {
        super.onDestroy()
        AppLog.d(TAG, "onDestroy")
        cleanupPreviousSession()
        renderScript?.destroy()
    }
}

/**
 * Full-screen, non-touchable view that draws the latest captured frame
 * with brightness/saturation/contrast/vignette/fisheye/blur/bloom applied.
 */
class FxRenderView(
    context: Context,
    private val rs: RenderScript?
) : View(context) {

    @Volatile private var latestBitmap: Bitmap? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val colorBakePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val bloomPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
    }

    // Bloom result, computed off the main draw path in updateFrame() so onDraw stays cheap.
    @Volatile private var latestBloom: Bitmap? = null

    // --- Fisheye mesh state ---
    // Note: this view runs LAYER_TYPE_SOFTWARE (see init{} below) specifically
    // because drawBitmapMesh's vertex displacement is unreliable on the
    // hardware-accelerated canvas.
    private val meshW = 24
    private val meshH = 32
    private val meshVerts = FloatArray((meshW + 1) * (meshH + 1) * 2)
    private var meshBuiltForWidth = -1
    private var meshBuiltForHeight = -1
    private var meshBuiltForStrength = -1f

    init {
        // CRITICAL: must be SOFTWARE, not HARDWARE.
        // Android's hardware-accelerated canvas (hwui/Skia GPU backend) only
        // supports a subset of Canvas/Paint operations. Two of them are used
        // here and BOTH silently misbehave under LAYER_TYPE_HARDWARE instead
        // of throwing, which is why this was invisible until traced:
        //  - drawBitmapMesh: on hardware layers this can render as a plain
        //    rectangular blit, ignoring the mesh vertex displacement entirely
        //    -> the fisheye warp geometry was simply never applied.
        //  - Paint.xfermode with PorterDuff.Mode.SCREEN: several blend modes
        //    are unsupported/approximated on the GPU backend. Instead of a
        //    proper screen-blend (which is a no-op for black), the bloom
        //    layer's black background was composited as ordinary alpha-over-black
        //    -> it visibly darkened the whole frame instead of glowing it.
        // Software rendering executes the real Skia CPU path, where both
        // operations are fully implemented and behave as documented.
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        rebuildColorFilter()
    }

    private fun rebuildColorFilter() {
        val b = FxSettings.brightness
        val s = FxSettings.saturation
        val c = FxSettings.contrast

        val saturationMatrix = ColorMatrix()
        saturationMatrix.setSaturation(s)

        val contrastMatrix = ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, (-0.5f * c + 0.5f) * 255f,
                0f, c, 0f, 0f, (-0.5f * c + 0.5f) * 255f,
                0f, 0f, c, 0f, (-0.5f * c + 0.5f) * 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )

        val brightnessMatrix = ColorMatrix(
            floatArrayOf(
                1f, 0f, 0f, 0f, (b - 1f) * 255f,
                0f, 1f, 0f, 0f, (b - 1f) * 255f,
                0f, 0f, 1f, 0f, (b - 1f) * 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )

        val combined = ColorMatrix()
        combined.postConcat(saturationMatrix)
        combined.postConcat(contrastMatrix)
        combined.postConcat(brightnessMatrix)

        paint.colorFilter = null // keep the shared draw/mesh paint free of the filter
        colorBakePaint.colorFilter = ColorMatrixColorFilter(combined)
    }

    private var lastLoggedB = -999f
    private var lastLoggedS = -999f
    private var lastLoggedC = -999f

    fun updateFrame(bitmap: Bitmap) {
        rebuildColorFilter()

        if (FxSettings.brightness != lastLoggedB || FxSettings.saturation != lastLoggedS || FxSettings.contrast != lastLoggedC) {
            lastLoggedB = FxSettings.brightness
            lastLoggedS = FxSettings.saturation
            lastLoggedC = FxSettings.contrast
            loggedColorBakeOnce = false
            AppLog.d("FxRenderView", "Цвет: brightness=${FxSettings.brightness} saturation=${FxSettings.saturation} contrast=${FxSettings.contrast}")
        }

        // Bake brightness/saturation/contrast directly into the bitmap here,
        // rather than relying on paint.colorFilter at draw time. drawBitmapMesh
        // (used below for the fisheye warp) does not reliably apply the
        // Paint's colorFilter — it's a known Skia/Canvas quirk — so if the
        // color adjustments only lived in `paint`, they would silently vanish
        // whenever fisheye > 0. Baking them in first makes color correct
        // regardless of which draw path (plain blit or mesh warp) runs next.
        val colorAdjusted = try {
            applyColorMatrix(bitmap)
        } catch (t: Throwable) {
            AppLog.e("FxRenderView", "Color matrix bake failed, using original frame", t)
            bitmap
        }

        val blurAmount = FxSettings.blur
        val blurred = if (blurAmount > 0.01f && rs != null) {
            applyBlur(colorAdjusted, blurAmount)
        } else {
            colorAdjusted
        }

        val bloomAmount = FxSettings.bloom
        latestBloom = if (bloomAmount > 0.01f && rs != null) {
            try {
                buildBloomLayer(blurred, bloomAmount)
            } catch (t: Throwable) {
                AppLog.e("FxRenderView", "Bloom failed", t)
                null
            }
        } else {
            null
        }

        latestBitmap = blurred
        post { invalidate() }
    }

    private var loggedColorBakeOnce = false

    private fun applyColorMatrix(src: Bitmap): Bitmap {
        val b = FxSettings.brightness
        val s = FxSettings.saturation
        val c = FxSettings.contrast
        // Skip the extra full-res draw entirely when all three are neutral —
        // this is the common case and keeps the hot path cheap.
        if (kotlin.math.abs(b - 1f) < 0.005f && kotlin.math.abs(s - 1f) < 0.005f && kotlin.math.abs(c - 1f) < 0.005f) {
            AppLog.d("FxRenderView", "applyColorMatrix: b/s/c all neutral, skipping bake (returning original bitmap)")
            return src
        }
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        canvas.drawBitmap(src, 0f, 0f, colorBakePaint)

        if (!loggedColorBakeOnce) {
            loggedColorBakeOnce = true
            try {
                val cx = src.width / 2
                val cy = src.height / 2
                val before = src.getPixel(cx, cy)
                val after = out.getPixel(cx, cy)
                AppLog.d(
                    "FxRenderView",
                    "COLOR BAKE CHECK — центральный пиксель до: " +
                        "R=${Color.red(before)} G=${Color.green(before)} B=${Color.blue(before)} A=${Color.alpha(before)}" +
                        " | после: R=${Color.red(after)} G=${Color.green(after)} B=${Color.blue(after)} A=${Color.alpha(after)}" +
                        " | filter=${colorBakePaint.colorFilter} | b=$b s=$s c=$c" +
                        " | identical=${before == after}"
                )
            } catch (t: Throwable) {
                AppLog.e("FxRenderView", "Не удалось прочитать пиксели для диагностики", t)
            }
        }

        return out
    }

    private fun applyBlur(src: Bitmap, amount: Float): Bitmap {
        return try {
            // Downscale for performance before blurring — full-res RS blur is too slow for real-time.
            val scale = 0.35f
            val small = Bitmap.createScaledBitmap(
                src, (src.width * scale).toInt().coerceAtLeast(1),
                (src.height * scale).toInt().coerceAtLeast(1), true
            )
            val input = Allocation.createFromBitmap(rs, small)
            val output = Allocation.createTyped(rs, input.type)
            val script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs))
            script.setRadius((amount * 25f).coerceIn(1f, 25f))
            script.setInput(input)
            script.forEach(output)
            output.copyTo(small)
            Bitmap.createScaledBitmap(small, src.width, src.height, true)
        } catch (t: Throwable) {
            AppLog.e("FxRenderView", "Blur failed, showing unblurred frame", t)
            src
        }
    }

    /**
     * Bloom: keep only pixels brighter than a threshold (soft knee, not a hard
     * cutoff), scaling their contribution by how far over the threshold they
     * are — so a near-white pixel contributes far more glow than a
     * just-barely-bright one. That bright-only layer is then heavily blurred
     * so it spreads into a soft halo, and later screen-blended back onto the
     * frame in onDraw(). "amount" controls both the threshold (lower
     * threshold = more of the image blooms) and the blur radius/strength.
     */
    private fun buildBloomLayer(src: Bitmap, amount: Float): Bitmap {
        // Work small: bloom is a low-frequency soft glow, doesn't need full res,
        // and this keeps threshold extraction + blur cheap enough for real-time.
        val scale = 0.25f
        val w = (src.width * scale).toInt().coerceAtLeast(1)
        val h = (src.height * scale).toInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(src, w, h, true)

        val pixels = IntArray(w * h)
        small.getPixels(pixels, 0, w, 0, 0, w, h)

        // More bloom strength -> lower threshold, so more of the image starts glowing.
        val threshold = (0.85f - amount * 0.45f).coerceIn(0.3f, 0.85f)
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = Color.red(p) / 255f
            val g = Color.green(p) / 255f
            val b = Color.blue(p) / 255f
            // Perceptual luminance decides how "bright" a pixel counts as.
            val luma = 0.2126f * r + 0.7152f * g + 0.0722f * b
            if (luma <= threshold) {
                // Fully transparent, not just black: this is drawn back with
                // SCREEN blending where opaque black is already a no-op, but
                // making it truly transparent means even a device/driver that
                // falls back to plain alpha compositing for this xfermode
                // still can't darken the frame — only the glow itself shows.
                pixels[i] = Color.TRANSPARENT
            } else {
                // Overshoot past the threshold, normalized 0..1, then boosted —
                // this is what makes brighter pixels bloom disproportionately harder.
                val over = ((luma - threshold) / (1f - threshold)).coerceIn(0f, 1f)
                val gain = (over * over) * (1f + amount * 1.5f)
                pixels[i] = Color.argb(
                    255,
                    (r * gain * 255f).toInt().coerceIn(0, 255),
                    (g * gain * 255f).toInt().coerceIn(0, 255),
                    (b * gain * 255f).toInt().coerceIn(0, 255)
                )
            }
        }
        small.setPixels(pixels, 0, w, 0, 0, w, h)

        val input = Allocation.createFromBitmap(rs, small)
        val output = Allocation.createTyped(rs, input.type)
        val script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs))
        script.setRadius((8f + amount * 17f).coerceIn(1f, 25f))
        script.setInput(input)
        script.forEach(output)
        output.copyTo(small)

        return small
    }

    private var loggedDrawOnce = false

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = latestBitmap ?: return

        if (!loggedDrawOnce) {
            loggedDrawOnce = true
            try {
                val cx = bmp.width / 2
                val cy = bmp.height / 2
                val px = bmp.getPixel(cx, cy)
                AppLog.d(
                    "FxRenderView",
                    "ONDRAW CHECK — рисуемый bitmap=${bmp.width}x${bmp.height}, view=${width}x${height}, " +
                        "центральный пиксель R=${Color.red(px)} G=${Color.green(px)} B=${Color.blue(px)}, " +
                        "fisheye=${FxSettings.fisheye}, vignette=${FxSettings.vignette}"
                )
            } catch (t: Throwable) {
                AppLog.e("FxRenderView", "onDraw diagnostic failed", t)
            }
        }

        val fisheye = FxSettings.fisheye
        if (fisheye > 0.01f && bmp.width > 0 && bmp.height > 0) {
            buildFisheyeMesh(fisheye, bmp.width, bmp.height)
            canvas.save()
            // drawBitmapMesh verts are in the bitmap's own coordinate space, so
            // scale the canvas from bitmap size to view size first (the two
            // are normally equal — both full screen — but this keeps it
            // correct if they ever diverge).
            canvas.scale(width / bmp.width.toFloat(), height / bmp.height.toFloat())
            canvas.drawBitmapMesh(bmp, meshW, meshH, meshVerts, 0, null, 0, paint)
            canvas.restore()
        } else {
            val srcRect = Rect(0, 0, bmp.width, bmp.height)
            val dstRect = Rect(0, 0, width, height)
            canvas.drawBitmap(bmp, srcRect, dstRect, paint)
        }

        latestBloom?.let { bloom ->
            val srcRect = Rect(0, 0, bloom.width, bloom.height)
            val dstRect = Rect(0, 0, width, height)
            canvas.drawBitmap(bloom, srcRect, dstRect, bloomPaint)
        }

        val vignette = FxSettings.vignette
        if (vignette > 0.01f) {
            drawVignette(canvas, vignette)
        }
    }

    /**
     * Builds a bulging barrel-distortion mesh: each grid vertex is pushed
     * outward from center by an amount that grows with distance from center
     * (a classic r' = r * (1 + k*r^2) style warp, normalized to the view's
     * half-diagonal). This is what actually makes the image look like it's
     * bulging through a fisheye/glass-dome lens, not just darkened at the
     * edges. Rebuilt only when size or strength changes, not every frame.
     */
    private fun buildFisheyeMesh(strength: Float, bmpWidth: Int, bmpHeight: Int) {
        if (meshBuiltForWidth == bmpWidth && meshBuiltForHeight == bmpHeight && meshBuiltForStrength == strength) {
            return
        }
        val w = bmpWidth.toFloat()
        val h = bmpHeight.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val maxR = kotlin.math.hypot(cx, cy)
        // k controls bulge intensity; tuned so strength=1 gives a strong, obviously
        // spherical bulge without folding pixels back on themselves at the corners.
        val k = strength * 0.55f

        var index = 0
        for (yi in 0..meshH) {
            val fy = h * yi / meshH
            for (xi in 0..meshW) {
                val fx = w * xi / meshW
                val dx = fx - cx
                val dy = fy - cy
                val r = kotlin.math.hypot(dx, dy) / maxR // normalized 0..1
                // Bulge outward: pixels near center move little, pixels near
                // the edge get pushed further out, producing the classic
                // convex "looking through a glass sphere" distortion.
                val factor = 1f + k * (r * r)
                val nx = (cx + dx * factor).coerceIn(0f, w)
                val ny = (cy + dy * factor).coerceIn(0f, h)
                meshVerts[index++] = nx
                meshVerts[index++] = ny
            }
        }
        meshBuiltForWidth = bmpWidth
        meshBuiltForHeight = bmpHeight
        meshBuiltForStrength = strength
    }

    private fun drawVignette(canvas: Canvas, strength: Float) {
        val cx = width / 2f
        val cy = height / 2f
        val radius = (width.coerceAtLeast(height)) * (1.1f - strength * 0.5f)

        val vignettePaint = Paint()
        vignettePaint.shader = RadialGradient(
            cx, cy, radius,
            intArrayOf(Color.TRANSPARENT, Color.BLACK),
            floatArrayOf(1f - strength, 1f),
            Shader.TileMode.CLAMP
        )
        vignettePaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_OVER)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), vignettePaint)
    }
}
