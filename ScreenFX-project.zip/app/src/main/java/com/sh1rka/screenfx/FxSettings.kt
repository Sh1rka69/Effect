package com.sh1rka.screenfx

import android.content.Context

/**
 * Simple in-memory + persisted store for effect parameters.
 * Values are normalized:
 *  - brightness: 0f..2f (1f = neutral)
 *  - saturation: 0f..2f (1f = neutral, 0f = grayscale)
 *  - contrast:   0f..2f (1f = neutral)
 *  - vignette:   0f..1f (0f = off) — edge darkening only
 *  - fisheye:    0f..1f (0f = off) — actual barrel-distortion bulge of the image
 *  - blur:       0f..1f (0f = off)
 *  - bloom:      0f..1f (0f = off) — soft glow around bright pixels, stronger the brighter the pixel
 */
object FxSettings {
    var brightness: Float = 1f
    var saturation: Float = 1f
    var contrast: Float = 1f
    var vignette: Float = 0f
    var fisheye: Float = 0f
    var blur: Float = 0f
    var bloom: Float = 0f

    private const val PREFS = "screenfx_prefs"

    fun save(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit()
            .putFloat("brightness", brightness)
            .putFloat("saturation", saturation)
            .putFloat("contrast", contrast)
            .putFloat("vignette", vignette)
            .putFloat("fisheye", fisheye)
            .putFloat("blur", blur)
            .putFloat("bloom", bloom)
            .apply()
    }

    fun load(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        brightness = prefs.getFloat("brightness", 1f)
        saturation = prefs.getFloat("saturation", 1f)
        contrast = prefs.getFloat("contrast", 1f)
        vignette = prefs.getFloat("vignette", 0f)
        fisheye = prefs.getFloat("fisheye", 0f)
        blur = prefs.getFloat("blur", 0f)
        bloom = prefs.getFloat("bloom", 0f)
    }
}
