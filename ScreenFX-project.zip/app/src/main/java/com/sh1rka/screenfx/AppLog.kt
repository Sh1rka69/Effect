package com.sh1rka.screenfx

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Very small persistent logger so the user can see what happened
 * even without a PC / adb — everything gets written to a file and
 * can be viewed + copied from LogActivity.
 */
object AppLog {
    private const val FILE_NAME = "screenfx_log.txt"
    private val timeFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Volatile private var logFile: File? = null

    fun init(context: Context) {
        if (logFile == null) {
            logFile = File(context.filesDir, FILE_NAME)
        }
    }

    fun d(tag: String, msg: String) {
        Log.d(tag, msg)
        write("D", tag, msg)
    }

    fun e(tag: String, msg: String, t: Throwable? = null) {
        Log.e(tag, msg, t)
        val full = if (t != null) "$msg\n${Log.getStackTraceString(t)}" else msg
        write("E", tag, full)
    }

    private fun write(level: String, tag: String, msg: String) {
        val file = logFile ?: return
        try {
            val line = "${timeFormat.format(Date())} $level/$tag: $msg\n"
            file.appendText(line)
        } catch (_: Exception) {
            // If logging itself fails, there's nothing more we can do here.
        }
    }

    fun readAll(): String {
        val file = logFile ?: return "(лог ещё не инициализирован)"
        return try {
            if (file.exists()) file.readText() else "(лог пуст — ошибок ещё не было)"
        } catch (e: Exception) {
            "Не удалось прочитать лог: ${e.message}"
        }
    }

    fun clear() {
        try {
            logFile?.writeText("")
        } catch (_: Exception) {
        }
    }

    /**
     * Installs a global handler so ANY uncaught crash anywhere in the app
     * (activity or service) gets written to the log file before the app dies.
     */
    fun installCrashHandler(context: Context) {
        init(context)
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            e("CRASH", "Необработанное исключение в потоке ${thread.name}", throwable)
            previous?.uncaughtException(thread, throwable)
        }
    }
}
