package com.sh1rka.screenfx

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {

    private lateinit var seekBrightness: SeekBar
    private lateinit var seekSaturation: SeekBar
    private lateinit var seekContrast: SeekBar
    private lateinit var seekVignette: SeekBar
    private lateinit var seekBlur: SeekBar

    private val projectionRequestCode = 4242

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        seekBrightness = findViewById(R.id.seekBrightness)
        seekSaturation = findViewById(R.id.seekSaturation)
        seekContrast = findViewById(R.id.seekContrast)
        seekVignette = findViewById(R.id.seekVignette)
        seekBlur = findViewById(R.id.seekBlur)

        // Restore last-used settings so the UI is not blank on relaunch
        FxSettings.load(this)
        seekBrightness.progress = (FxSettings.brightness * 100).toInt()
        seekSaturation.progress = (FxSettings.saturation * 100).toInt()
        seekContrast.progress = (FxSettings.contrast * 100).toInt()
        seekVignette.progress = (FxSettings.vignette * 100).toInt()
        seekBlur.progress = (FxSettings.blur * 100).toInt()

        val btnGrantOverlay: MaterialButton = findViewById(R.id.btnGrantOverlay)
        val btnApply: MaterialButton = findViewById(R.id.btnApply)
        val btnStop: MaterialButton = findViewById(R.id.btnStop)

        updateOverlayButtonState(btnGrantOverlay)

        btnGrantOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "Разрешение уже выдано", Toast.LENGTH_SHORT).show()
            }
        }

        btnApply.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Сначала выдай разрешение «поверх экрана»", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            FxSettings.brightness = seekBrightness.progress / 100f
            FxSettings.saturation = seekSaturation.progress / 100f
            FxSettings.contrast = seekContrast.progress / 100f
            FxSettings.vignette = seekVignette.progress / 100f
            FxSettings.blur = seekBlur.progress / 100f
            FxSettings.save(this)

            requestScreenCapture()
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, OverlayFxService::class.java))
            Toast.makeText(this, "Эффект выключен", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateOverlayButtonState(btn: MaterialButton) {
        btn.text = if (Settings.canDrawOverlays(this))
            "Разрешение «поверх экрана» ✓ выдано"
        else
            getString(R.string.grant_overlay)
    }

    override fun onResume() {
        super.onResume()
        updateOverlayButtonState(findViewById(R.id.btnGrantOverlay))
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequestCode)
    }

    @Deprecated("Using legacy API for broad compatibility down to API 26")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequestCode && resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, OverlayFxService::class.java).apply {
                putExtra(OverlayFxService.EXTRA_RESULT_CODE, resultCode)
                putExtra(OverlayFxService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ActivityCompat.startForegroundService(this, serviceIntent)
            } else {
                startService(serviceIntent)
            }
            Toast.makeText(this, "Эффект применён. Сверни приложение и играй.", Toast.LENGTH_LONG).show()
        } else if (requestCode == projectionRequestCode) {
            Toast.makeText(this, "Захват экрана не разрешён — эффект не может работать без него", Toast.LENGTH_LONG).show()
        }
    }
}
